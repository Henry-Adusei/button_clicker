function login_btn(element) {
    element.innerText = 'LogOut'
}

function remove_def(element) {
    element.remove();
}